Film Lab / kodak_portra_800_push1 / kodak_endura_premier
Camera: LUMIX S1RII (S1RII, DC-S1RM2)

1101STD.cube: S1RII Standard -> V-Log Alchemy adapter -> original creative VLOG.
1101VLOG.cube: unchanged Panasonic V-Log / V-Gamut -> sRGB renderer.
Both are 33 x 33 x 33, full range 0..1. Apply only one creative cube.
STD: select this exact camera model, unadjusted Standard base, LUT opacity 100%.
VLOG: supply real Panasonic V-Log/V-Gamut. Do not add a second display conversion.
GH6 Standard output is post-processing only. DC-L10 does not mean DMC-L10.

The merged STD uses adapter trilinear -> serialized creative tetrahedral, then
nine-decimal 33-grid export. It contains no Film Lab B precurve, chroma gain,
automatic exposure or added colour correction. Browser previews use the same
merged cube. QA compares the serialized cube against the sequential transform;
it does not establish physical film accuracy or a camera-specific match.

Source adapter: https://github.com/shenmintao/V-Log-Alchemy/blob/e51ba9a23458ff5c316f630b860eb0201139d126/Luts/Panasonic-Standard/Conversion/S1RIIS2V.cube
Adapter modified by Film Lab: smoothed only in colours with no nearby camera
sample (fixes a cyan band in blue skies); neutral axis unchanged.
Adapter SHA256 (Film Lab smoothed): 8ed262f2500a55e3c437339aaf371664cc444276f6a15e34c077c5dcd8d1ff12
Creative VLOG SHA256: 19836ce35aac5fe1c8d38c22e16e8da9635ee1cfc0cf9a071c35130c9e7b6e4e
Upstream camera calibration status: controlled.

Modified by Film Lab: merged camera Standard adapter and creative VLOG renderer.
V-Log Alchemy by shenmintao, Apache-2.0; license included.
spektrafilm by Andrea Volpato, https://github.com/andreavolpato/spektrafilm
SPEKTRAFILM_LICENSE.txt and spektrafilm-LICENSE.txt preserve upstream terms.
FUJIFILM source rights remain separate where FUJIFILM_NOTICE.txt is included.

- Standard clipping and gamut compression cannot be inverted exactly; clipped highlights and colours cannot be restored.
- Use the exact camera model and unadjusted Standard Photo Style. No automatic exposure or image statistics are applied.
- Camera cube interpolation is undocumented; tetrahedral and trilinear rebake error are both reported.
- Native V-Log acquisition gain, noise and highlight headroom cannot be recreated by an output LUT.
